// HX OS — app.js
// WebSocket connection to C# backend
var ws = null;
var wsConnected = false;
var startTime = Date.now();

function connectWS() {
  try {
    ws = new WebSocket('ws://localhost:5000/ws');
    ws.onopen = function() {
      wsConnected = true;
      console.log('HX Backend connected');
    };
    ws.onmessage = function(e) {
      var data = JSON.parse(e.data);
      handleBackendMessage(data);
    };
    ws.onclose = function() {
      wsConnected = false;
      setTimeout(connectWS, 3000); // reconnect
    };
    ws.onerror = function() {
      wsConnected = false;
    };
  } catch(err) {
    console.log('Backend not available, running in demo mode');
  }
}

function sendWS(payload) {
  if (wsConnected && ws) {
    ws.send(JSON.stringify(payload));
  }
}

function handleBackendMessage(data) {
  if (data.type === 'sysinfo') {
    updateSysInfo(data.cpu, data.ram, data.disk);
  }
  if (data.type === 'ls') {
    renderFiles(data.entries);
  }
  if (data.type === 'exec') {
    appendTerminalLine(data.output, 't-out');
  }
  if (data.type === 'error') {
    appendTerminalLine(data.message, 't-err');
  }
}

// ── Window management ──────────────────────────────────────────

function toggleWin(id) {
  var w = document.getElementById('win-' + id);
  var di = document.getElementById('di-' + id);
  if (w.classList.contains('open')) {
    w.classList.remove('open', 'focused');
    di.classList.remove('active');
  } else {
    w.classList.add('open', 'focused');
    di.classList.add('active');
    bringToFront(w);
    onWindowOpen(id);
  }
}

function closeWin(id) {
  document.getElementById('win-' + id).classList.remove('open', 'focused');
  document.getElementById('di-' + id).classList.remove('active');
}

function bringToFront(win) {
  document.querySelectorAll('.win').forEach(function(w) { w.classList.remove('focused'); });
  win.classList.add('focused');
}

function onWindowOpen(id) {
  if (id === 'sysinfo') { updateSysInfoDemo(); }
  if (id === 'files') { sendWS({ cmd: 'ls', path: '/home/user' }); }
}

// Make windows draggable and focusable
['terminal', 'sysinfo', 'files', 'settings', 'about'].forEach(function(id) {
  var win = document.getElementById('win-' + id);
  var tb  = document.getElementById('drag-' + id);

  win.addEventListener('mousedown', function() { bringToFront(win); });

  tb.addEventListener('mousedown', function(e) {
    if (e.target.classList.contains('wb')) return;
    var startX = e.clientX - win.offsetLeft;
    var startY = e.clientY - win.offsetTop;

    function onMove(e) {
      var desk = document.getElementById('desktop');
      var nx = Math.max(0, Math.min(e.clientX - startX, desk.offsetWidth - win.offsetWidth));
      var ny = Math.max(0, Math.min(e.clientY - startY, desk.offsetHeight - win.offsetHeight));
      win.style.left = nx + 'px';
      win.style.top  = ny + 'px';
    }
    function onUp() {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    }
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    e.preventDefault();
  });
});

// ── Clock ──────────────────────────────────────────────────────

function updateClock() {
  var now = new Date();
  var h = String(now.getHours()).padStart(2, '0');
  var m = String(now.getMinutes()).padStart(2, '0');
  document.getElementById('clk').textContent = h + ':' + m;
}
updateClock();
setInterval(updateClock, 10000);

// ── System Info ────────────────────────────────────────────────

function updateSysInfo(cpu, ram, disk) {
  document.getElementById('cpu-val').textContent = Math.round(cpu) + '%';
  document.getElementById('ram-val').textContent = Math.round(ram) + '%';
  document.getElementById('disk-val').textContent = Math.round(disk) + '%';
  document.getElementById('cpu-bar').style.width = Math.round(cpu) + '%';
  document.getElementById('ram-bar').style.width = Math.round(ram) + '%';
  document.getElementById('disk-bar').style.width = Math.round(disk) + '%';
  var elapsed = Math.floor((Date.now() - startTime) / 60000);
  var h = Math.floor(elapsed / 60);
  var m = elapsed % 60;
  var uptimeStr = h + 'h ' + m + 'm';
  document.getElementById('si-uptime').textContent = uptimeStr;
  document.getElementById('term-uptime').textContent = 'up ' + uptimeStr + ', 1 user, load avg: ' + (cpu / 100).toFixed(2);
}

function updateSysInfoDemo() {
  // Demo mode — simulated values when backend is not connected
  var cpu = Math.round(25 + Math.random() * 30);
  var ram = Math.round(50 + Math.random() * 20);
  var disk = 28;
  updateSysInfo(cpu, ram, disk);
}

// Poll backend or demo every 4s
setInterval(function() {
  if (wsConnected) {
    sendWS({ cmd: 'sysinfo' });
  } else {
    updateSysInfoDemo();
  }
}, 4000);

// ── Terminal ───────────────────────────────────────────────────

var termHistory = [];
var termHistIdx = -1;

function appendTerminalLine(text, cls) {
  var out = document.getElementById('term-output');
  var line = document.createElement('div');
  line.className = 't-line ' + (cls || '');
  line.textContent = text;
  out.appendChild(line);
  out.scrollTop = out.scrollHeight;
}

function termCommand(e) {
  if (e.key === 'Enter') {
    var input = document.getElementById('term-input');
    var cmd = input.value.trim();
    if (!cmd) return;

    termHistory.unshift(cmd);
    termHistIdx = -1;
    input.value = '';

    // Echo command
    var out = document.getElementById('term-output');
    var line = document.createElement('div');
    line.className = 't-line';
    line.innerHTML = '<span class="t-p">hxos</span><span class="t-sep">:~$ </span><span class="t-cmd">' + escapeHtml(cmd) + '</span>';
    out.appendChild(line);

    // Handle built-in commands
    handleTermCommand(cmd);
    out.scrollTop = out.scrollHeight;
  }
  if (e.key === 'ArrowUp') {
    termHistIdx = Math.min(termHistIdx + 1, termHistory.length - 1);
    document.getElementById('term-input').value = termHistory[termHistIdx] || '';
  }
  if (e.key === 'ArrowDown') {
    termHistIdx = Math.max(termHistIdx - 1, -1);
    document.getElementById('term-input').value = termHistIdx >= 0 ? termHistory[termHistIdx] : '';
  }
}

function handleTermCommand(cmd) {
  var parts = cmd.split(' ');
  var base = parts[0].toLowerCase();

  var builtins = {
    'help': function() {
      ['Available commands:', '  help       — show this', '  clear      — clear terminal',
       '  ls         — list files', '  pwd        — print directory', '  whoami     — current user',
       '  uname      — system info', '  uptime     — system uptime', '  echo <txt> — print text',
       '  date       — current date/time'].forEach(function(l) { appendTerminalLine(l, 't-out'); });
    },
    'clear': function() {
      document.getElementById('term-output').innerHTML = '';
    },
    'ls': function() {
      appendTerminalLine('Documents  Downloads  Pictures  Music  Desktop  readme.txt  config.cfg  notes.txt', 't-out');
    },
    'pwd': function() { appendTerminalLine('/home/user', 't-out'); },
    'whoami': function() { appendTerminalLine('user', 't-out'); },
    'uname': function() { appendTerminalLine('HX OS 0.1.0 x86_64 GNU/Linux (kernel 6.8.0-hx)', 't-out'); },
    'uptime': function() {
      var m = Math.floor((Date.now() - startTime) / 60000);
      appendTerminalLine('up ' + Math.floor(m/60) + 'h ' + (m%60) + 'm, 1 user, load avg: 0.42', 't-out');
    },
    'echo': function() { appendTerminalLine(parts.slice(1).join(' '), 't-out'); },
    'date': function() { appendTerminalLine(new Date().toString(), 't-out'); },
    'neofetch': function() {
      ['   HX OS 0.1.0', '   ─────────────', '   OS: HX OS 0.1.0 x86_64', '   Kernel: 6.8.0-hx',
       '   Shell: HXShell (C# .NET 8)', '   GUI: Chromium kiosk', '   Arch: x86_64'].forEach(function(l) {
        appendTerminalLine(l, 't-out');
      });
    }
  };

  if (builtins[base]) {
    builtins[base]();
  } else if (wsConnected) {
    sendWS({ cmd: 'exec', command: cmd });
  } else {
    appendTerminalLine('Command not found: ' + base + ' (try "help")', 't-err');
  }
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── File Manager ───────────────────────────────────────────────

var currentPath = '/home/user';
var pathHistory = [];

function filesOpen(name, type) {
  if (type === 'dir') {
    pathHistory.push(currentPath);
    currentPath = currentPath + '/' + name;
    document.getElementById('fi-path').textContent = currentPath;
    document.getElementById('files-path-title').textContent = 'File Manager — ' + currentPath;
    if (wsConnected) {
      sendWS({ cmd: 'ls', path: currentPath });
    } else {
      showNotif('Opened: ' + name);
    }
  }
}

function filesBack() {
  if (pathHistory.length > 0) {
    currentPath = pathHistory.pop();
    document.getElementById('fi-path').textContent = currentPath;
    document.getElementById('files-path-title').textContent = 'File Manager — ' + currentPath;
    if (wsConnected) { sendWS({ cmd: 'ls', path: currentPath }); }
  }
}

function renderFiles(entries) {
  var grid = document.getElementById('fi-grid');
  grid.innerHTML = '';
  entries.forEach(function(entry) {
    var item = document.createElement('div');
    item.className = 'fi-item';
    var ico = entry.isDir ? '&#128193;' : '&#128196;';
    item.innerHTML = '<div class="fi-ico">' + ico + '</div><span class="fi-name">' + entry.name + '</span>';
    item.ondblclick = function() { filesOpen(entry.name, entry.isDir ? 'dir' : 'file'); };
    grid.appendChild(item);
  });
}

// ── Settings ───────────────────────────────────────────────────

function toggleDark() {
  document.body.classList.toggle('dark');
  document.getElementById('tog-dark').classList.toggle('off');
}

// ── Notification ───────────────────────────────────────────────

var notifTimer = null;
function showNotif(msg) {
  var el = document.getElementById('notif');
  el.textContent = msg;
  el.classList.add('show');
  if (notifTimer) clearTimeout(notifTimer);
  notifTimer = setTimeout(function() { el.classList.remove('show'); }, 2500);
}

// ── Boot ───────────────────────────────────────────────────────

connectWS();
setTimeout(updateSysInfoDemo, 500);
