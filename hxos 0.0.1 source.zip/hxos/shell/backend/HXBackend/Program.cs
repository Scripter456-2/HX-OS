// HX OS Backend — Program.cs
// WebSocket server connecting the Chromium frontend to Linux system calls

using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Diagnostics;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://localhost:5000");
var app = builder.Build();

app.UseWebSockets(new WebSocketOptions { KeepAliveInterval = TimeSpan.FromSeconds(30) });

// Serve frontend files
app.UseStaticFiles(new StaticFileOptions {
    FileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(
        Path.Combine(AppContext.BaseDirectory, "frontend")),
    RequestPath = ""
});

// WebSocket endpoint
app.Map("/ws", async context => {
    if (!context.WebSockets.IsWebSocketRequest) {
        context.Response.StatusCode = 400;
        return;
    }

    var ws = await context.WebSockets.AcceptWebSocketAsync();
    Console.WriteLine("[HX Backend] Client connected");

    var buffer = new byte[8192];

    while (ws.State == WebSocketState.Open) {
        try {
            var result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
            if (result.MessageType == WebSocketMessageType.Close) break;

            var json = Encoding.UTF8.GetString(buffer, 0, result.Count);
            var msg = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
            if (msg == null) continue;

            string response = msg.GetValueOrDefault("cmd", "") switch {
                "sysinfo" => await GetSysInfoAsync(),
                "ls"      => ListFiles(msg.GetValueOrDefault("path", "/home/user")),
                "exec"    => RunCommand(msg.GetValueOrDefault("command", "")),
                _         => Err("unknown command")
            };

            var bytes = Encoding.UTF8.GetBytes(response);
            await ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);

        } catch (Exception ex) {
            Console.WriteLine("[HX Backend] Error: " + ex.Message);
            break;
        }
    }

    Console.WriteLine("[HX Backend] Client disconnected");
});

Console.WriteLine("[HX Backend] Starting on ws://localhost:5000/ws");
await app.RunAsync();

// ── System Info ────────────────────────────────────────────────────────────

static async Task<string> GetSysInfoAsync() {
    double cpu = await GetCpuUsageAsync();
    (long used, long total) = GetMemInfo();
    int ram = total > 0 ? (int)(used * 100 / total) : 0;
    int disk = GetDiskUsage();

    return JsonSerializer.Serialize(new {
        type = "sysinfo",
        cpu  = Math.Round(cpu, 1),
        ram,
        disk
    });
}

static async Task<double> GetCpuUsageAsync() {
    try {
        var s1 = ReadCpuStat();
        await Task.Delay(500);
        var s2 = ReadCpuStat();
        long totalDiff = s2.total - s1.total;
        long idleDiff  = s2.idle  - s1.idle;
        if (totalDiff <= 0) return 0;
        return Math.Round((1.0 - (double)idleDiff / totalDiff) * 100, 1);
    } catch { return 0; }
}

static (long total, long idle) ReadCpuStat() {
    var line = File.ReadLines("/proc/stat").First();
    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
    long user    = long.Parse(parts[1]);
    long nice    = long.Parse(parts[2]);
    long system  = long.Parse(parts[3]);
    long idle    = long.Parse(parts[4]);
    long iowait  = long.Parse(parts[5]);
    long irq     = long.Parse(parts[6]);
    long softirq = long.Parse(parts[7]);
    long total   = user + nice + system + idle + iowait + irq + softirq;
    return (total, idle);
}

static (long used, long total) GetMemInfo() {
    try {
        var lines = File.ReadAllLines("/proc/meminfo");
        long total = ParseMemLine(lines[0]);
        long free  = ParseMemLine(lines[1]);
        long buffers = ParseMemLine(lines.FirstOrDefault(l => l.StartsWith("Buffers:")) ?? "Buffers: 0 kB");
        long cached  = ParseMemLine(lines.FirstOrDefault(l => l.StartsWith("Cached:"))  ?? "Cached: 0 kB");
        long used = total - free - buffers - cached;
        return (used, total);
    } catch { return (0, 1); }
}

static long ParseMemLine(string line) {
    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
    return parts.Length >= 2 ? long.Parse(parts[1]) : 0;
}

static int GetDiskUsage() {
    try {
        var info = new DriveInfo("/");
        return (int)((info.TotalSize - info.AvailableFreeSpace) * 100 / info.TotalSize);
    } catch { return 0; }
}

// ── File listing ───────────────────────────────────────────────────────────

static string ListFiles(string path) {
    try {
        if (!Directory.Exists(path)) return Err("Directory not found: " + path);
        var entries = Directory.GetFileSystemEntries(path)
            .OrderBy(e => !Directory.Exists(e))
            .ThenBy(e => Path.GetFileName(e))
            .Select(e => new {
                name  = Path.GetFileName(e),
                isDir = Directory.Exists(e),
                size  = Directory.Exists(e) ? 0L : new FileInfo(e).Length
            });
        return JsonSerializer.Serialize(new { type = "ls", entries });
    } catch (Exception ex) {
        return Err(ex.Message);
    }
}

// ── Shell command execution ────────────────────────────────────────────────

static string RunCommand(string cmd) {
    if (string.IsNullOrWhiteSpace(cmd)) return Err("No command");

    // Safety: block dangerous commands
    var blocked = new[] { "rm -rf", "mkfs", "dd if", ":(){ :|:", "> /dev/sda", "shutdown", "reboot" };
    if (blocked.Any(b => cmd.Contains(b))) return Err("Command blocked for safety");

    try {
        var psi = new ProcessStartInfo("bash") {
            Arguments = "-c \"" + cmd.Replace("\"", "\\\"") + "\"",
            RedirectStandardOutput = true,
            RedirectStandardError  = true,
            UseShellExecute        = false
        };
        var p = Process.Start(psi)!;
        p.WaitForExit(5000);
        var output = p.StandardOutput.ReadToEnd() + p.StandardError.ReadToEnd();
        return JsonSerializer.Serialize(new { type = "exec", output = output.TrimEnd() });
    } catch (Exception ex) {
        return Err(ex.Message);
    }
}

static string Err(string msg) =>
    JsonSerializer.Serialize(new { type = "error", message = msg });
