#!/bin/bash
# HX OS — kernel-config.sh
# Run inside linux-6.8 source directory to apply HX OS kernel config
# Usage: cd kernel/linux-6.8 && bash ../../kernel-config/apply.sh

set -e

echo "[HX] Applying HX OS kernel config..."

make defconfig

# Graphics / Framebuffer
scripts/config --enable CONFIG_FB
scripts/config --enable CONFIG_FB_VESA
scripts/config --enable CONFIG_FB_EFI
scripts/config --enable CONFIG_DRM
scripts/config --enable CONFIG_DRM_FBDEV_EMULATION
scripts/config --enable CONFIG_FRAMEBUFFER_CONSOLE

# USB / Input
scripts/config --enable CONFIG_USB
scripts/config --enable CONFIG_USB_XHCI_HCD
scripts/config --enable CONFIG_USB_EHCI_HCD
scripts/config --enable CONFIG_HID
scripts/config --enable CONFIG_HID_GENERIC
scripts/config --enable CONFIG_USB_HID
scripts/config --enable CONFIG_INPUT_KEYBOARD
scripts/config --enable CONFIG_INPUT_MOUSE

# Network (for future use)
scripts/config --enable CONFIG_NET
scripts/config --enable CONFIG_INET
scripts/config --enable CONFIG_E1000
scripts/config --enable CONFIG_VIRTIO_NET

# Filesystems
scripts/config --enable CONFIG_EXT4_FS
scripts/config --enable CONFIG_VFAT_FS
scripts/config --enable CONFIG_TMPFS
scripts/config --enable CONFIG_PROC_FS
scripts/config --enable CONFIG_SYSFS
scripts/config --enable CONFIG_DEVTMPFS
scripts/config --enable CONFIG_DEVTMPFS_MOUNT

# VirtIO (for QEMU)
scripts/config --enable CONFIG_VIRTIO
scripts/config --enable CONFIG_VIRTIO_PCI
scripts/config --enable CONFIG_VIRTIO_BALLOON
scripts/config --enable CONFIG_VIRTIO_BLK
scripts/config --enable CONFIG_SCSI_VIRTIO

echo "[HX] Config applied. Run: make -j\$(nproc)"
