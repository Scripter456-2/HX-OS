# HX OS

A minimal, clean Linux-based OS with a web-based desktop GUI, written in C# (.NET 8).

## Stack

| Layer | Tech |
|---|---|
| Kernel | Linux 6.8 |
| Init | Custom shell script |
| Backend | C# / .NET 8 (WebSocket server) |
| Frontend | HTML + CSS + JS (Chromium kiosk) |
| Display | X11 + Chromium fullscreen |

## Project Structure

```
hxos/
├── build/
│   └── build.sh              ← master build script (run inside VM)
├── shell/
│   ├── frontend/
│   │   ├── index.html        ← desktop UI
│   │   ├── style.css         ← all styles + dark mode
│   │   └── app.js            ← window manager, terminal, file manager
│   └── backend/
│       └── HXBackend/
│           ├── HXBackend.csproj
│           └── Program.cs    ← WebSocket server (sysinfo, ls, exec)
├── kernel/                   ← created by build.sh (Linux source)
├── rootfs/                   ← created by build.sh
├── iso/                      ← created by build.sh
└── HX-OS.iso                 ← final output
```

## How to Build

### Requirements
- VirtualBox VM running Ubuntu 24.04
- Shared folder: your Windows project folder mounted at `/mnt/hxos`
- Internet access in the VM

### Step 1 — Install dependencies (in Ubuntu VM)
```bash
sudo apt update && sudo apt install -y \
  build-essential bison flex libelf-dev libssl-dev bc wget \
  xorriso grub-pc-bin grub-efi-amd64-bin cpio gzip \
  qemu-system-x86 dotnet-sdk-8.0 chromium-browser xorg
```

### Step 2 — Run the build
```bash
cd /mnt/hxos/build
chmod +x build.sh
./build.sh
```

This will:
1. Download and compile Linux kernel 6.8 (~20 min first time)
2. Compile the C# backend to a self-contained Linux binary
3. Assemble the rootfs with frontend + backend + Chromium
4. Pack initramfs and build the bootable ISO

### Step 3 — Test in QEMU
```bash
qemu-system-x86_64 \
  -cdrom /mnt/hxos/HX-OS.iso \
  -m 4G \
  -enable-kvm \
  -vga virtio
```

### Step 4 — Flash to USB (Windows)
1. Download Rufus: https://rufus.ie
2. Select `HX-OS.iso`
3. Select your USB drive
4. Click Start → boot from USB

## Desktop Features

| Feature | How to open |
|---|---|
| Terminal | Click terminal icon in dock |
| File Manager | Click folder icon in dock |
| System Info | Click chart icon in dock |
| Settings | Click gear icon in dock |
| About | Click info icon in dock |

### Terminal commands
`help`, `ls`, `pwd`, `whoami`, `uname`, `uptime`, `echo`, `date`, `neofetch`, `clear`

When the C# backend is running, all other Linux commands are passed through via bash.

### Dark mode
Open Settings → toggle Dark mode.

## Architecture

```
Chromium (kiosk mode, fullscreen)
    ↕ WebSocket ws://localhost:5000/ws
C# Backend (HXBackend)
    ↕ System calls
Linux Kernel 6.8
```

The frontend (HTML/CSS/JS) handles all UI. The C# backend provides:
- Real CPU/RAM/disk stats from `/proc`
- File system listing via `Directory.GetFileSystemEntries`
- Safe command execution via bash subprocess
